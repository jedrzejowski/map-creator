#pragma once
#include "header.h"

class WaterTerrain : public BaseTerrain {
public:
	WaterTerrain(BaseTerrain& terrain);

	virtual string GetSubsoil() override;
	
};