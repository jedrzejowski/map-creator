#define ErrorArgs 1
#define ErrorInputFile 2